var btnForm = document.querySelector('#btnForm');

btnForm.addEventListener('click', function(){  
    location.href="/lista/form"
})